/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import { create } from 'zustand';
import { GameStatus, RUN_SPEED_BASE } from './types';

interface PersistentUpgrades {
    doubleJump: boolean;
    immortality: boolean;
    extraLife: boolean;
}

interface GameState {
  status: GameStatus;
  score: number;
  lives: number;
  maxLives: number;
  speed: number;
  collectedLetters: number[]; 
  level: number;
  laneCount: number;
  gemsCollected: number;
  distance: number;
  
  // Persistent Data
  totalGems: number;
  purchasedUpgrades: PersistentUpgrades;

  // Inventory / Abilities
  hasDoubleJump: boolean;
  hasImmortality: boolean;
  isImmortalityActive: boolean;

  // Actions
  startGame: () => void;
  restartGame: () => void;
  takeDamage: () => void;
  addScore: (amount: number) => void;
  collectGem: (value: number) => void;
  collectLetter: (index: number) => void;
  setStatus: (status: GameStatus) => void;
  setDistance: (dist: number) => void;
  
  // Shop / Abilities
  buyItem: (type: 'DOUBLE_JUMP' | 'MAX_LIFE' | 'HEAL' | 'IMMORTAL', cost: number) => boolean;
  buyUpgrade: (type: keyof PersistentUpgrades, cost: number) => void;
  advanceLevel: () => void;
  openShop: () => void;
  closeShop: () => void;
  activateImmortality: () => void;
}

const GEMINI_TARGET = ['G', 'E', 'M', 'I', 'N', 'I'];
const MAX_LEVEL = 3;

// Helper to load/save
const loadGems = () => parseInt(localStorage.getItem('gemini_runner_gems') || '0');
const loadUpgrades = (): PersistentUpgrades => {
    try {
        const data = localStorage.getItem('gemini_runner_upgrades');
        return data ? JSON.parse(data) : { doubleJump: false, immortality: false, extraLife: false };
    } catch {
        return { doubleJump: false, immortality: false, extraLife: false };
    }
};

export const useStore = create<GameState>((set, get) => ({
  status: GameStatus.MENU,
  score: 0,
  lives: 3,
  maxLives: 3,
  speed: 0,
  collectedLetters: [],
  level: 1,
  laneCount: 3,
  gemsCollected: 0,
  distance: 0,
  
  totalGems: loadGems(),
  purchasedUpgrades: loadUpgrades(),
  
  hasDoubleJump: false,
  hasImmortality: false,
  isImmortalityActive: false,

  startGame: () => {
      const { purchasedUpgrades } = get();
      const baseMaxLives = 3;
      const startLives = purchasedUpgrades.extraLife ? baseMaxLives + 1 : baseMaxLives;

      set({ 
        status: GameStatus.PLAYING, 
        score: 0, 
        lives: startLives, 
        maxLives: startLives,
        speed: RUN_SPEED_BASE,
        collectedLetters: [],
        level: 1,
        laneCount: 3,
        gemsCollected: 0,
        distance: 0,
        hasDoubleJump: purchasedUpgrades.doubleJump,
        hasImmortality: purchasedUpgrades.immortality,
        isImmortalityActive: false
      });
  },

  restartGame: () => {
      const { purchasedUpgrades } = get();
      const baseMaxLives = 3;
      const startLives = purchasedUpgrades.extraLife ? baseMaxLives + 1 : baseMaxLives;

      set({ 
        status: GameStatus.PLAYING, 
        score: 0, 
        lives: startLives, 
        maxLives: startLives,
        speed: RUN_SPEED_BASE,
        collectedLetters: [],
        level: 1,
        laneCount: 3,
        gemsCollected: 0,
        distance: 0,
        hasDoubleJump: purchasedUpgrades.doubleJump,
        hasImmortality: purchasedUpgrades.immortality,
        isImmortalityActive: false
      });
  },

  takeDamage: () => {
    const { lives, isImmortalityActive } = get();
    if (isImmortalityActive) return; // No damage if skill is active

    if (lives > 1) {
      set({ lives: lives - 1 });
    } else {
      // Game Over Logic - Bank Gems
      const { totalGems, gemsCollected } = get();
      const newTotal = totalGems + gemsCollected;
      localStorage.setItem('gemini_runner_gems', newTotal.toString());

      set({ 
          lives: 0, 
          status: GameStatus.GAME_OVER, 
          speed: 0,
          totalGems: newTotal
      });
    }
  },

  addScore: (amount) => set((state) => ({ score: state.score + amount })),
  
  collectGem: (value) => set((state) => ({ 
    score: state.score + value, 
    gemsCollected: state.gemsCollected + 1 
  })),

  setDistance: (dist) => set({ distance: dist }),

  collectLetter: (index) => {
    const { collectedLetters, level, speed } = get();
    
    if (!collectedLetters.includes(index)) {
      const newLetters = [...collectedLetters, index];
      
      const speedIncrease = RUN_SPEED_BASE * 0.10;
      const nextSpeed = speed + speedIncrease;

      set({ 
        collectedLetters: newLetters,
        speed: nextSpeed
      });

      if (newLetters.length === GEMINI_TARGET.length) {
        if (level < MAX_LEVEL) {
            get().advanceLevel();
        } else {
            // Victory Logic - Bank Gems
            const { totalGems, gemsCollected, score } = get();
            const newTotal = totalGems + gemsCollected;
            localStorage.setItem('gemini_runner_gems', newTotal.toString());

            set({
                status: GameStatus.VICTORY,
                score: score + 5000,
                totalGems: newTotal
            });
        }
      }
    }
  },

  advanceLevel: () => {
      const { level, laneCount, speed } = get();
      const nextLevel = level + 1;
      const speedIncrease = RUN_SPEED_BASE * 0.40;
      const newSpeed = speed + speedIncrease;

      set({
          level: nextLevel,
          laneCount: Math.min(laneCount + 2, 9),
          status: GameStatus.PLAYING,
          speed: newSpeed,
          collectedLetters: [] 
      });
  },

  openShop: () => set({ status: GameStatus.SHOP }),
  
  closeShop: () => set({ status: GameStatus.PLAYING }),

  buyItem: (type, cost) => {
      const { score, maxLives, lives } = get();
      
      if (score >= cost) {
          set({ score: score - cost });
          
          switch (type) {
              case 'DOUBLE_JUMP':
                  set({ hasDoubleJump: true });
                  break;
              case 'MAX_LIFE':
                  set({ maxLives: maxLives + 1, lives: lives + 1 });
                  break;
              case 'HEAL':
                  set({ lives: Math.min(lives + 1, maxLives) });
                  break;
              case 'IMMORTAL':
                  set({ hasImmortality: true });
                  break;
          }
          return true;
      }
      return false;
  },

  buyUpgrade: (type, cost) => {
      const { totalGems, purchasedUpgrades } = get();
      if (totalGems >= cost) {
          const newUpgrades = { ...purchasedUpgrades, [type]: true };
          const newGems = totalGems - cost;
          
          localStorage.setItem('gemini_runner_gems', newGems.toString());
          localStorage.setItem('gemini_runner_upgrades', JSON.stringify(newUpgrades));

          set({ totalGems: newGems, purchasedUpgrades: newUpgrades });
      }
  },

  activateImmortality: () => {
      const { hasImmortality, isImmortalityActive } = get();
      if (hasImmortality && !isImmortalityActive) {
          set({ isImmortalityActive: true });
          setTimeout(() => {
              set({ isImmortalityActive: false });
          }, 5000);
      }
  },

  setStatus: (status) => set({ status }),
}));